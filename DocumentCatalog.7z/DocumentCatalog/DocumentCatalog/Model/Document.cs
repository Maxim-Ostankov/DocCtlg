﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DocumentCatalog.Model
{
    /// <summary>
    /// Документ каталога
    /// </summary>
    public class Document : CatalogItem
    {                
        /// <summary>
        /// Счетчик следующего отрицательного идентификатора документа
        /// </summary>
        private static int nextNewId { get; set; }

        private Document()
        {
            Id = --nextNewId;
            Name = string.Empty;
        }

        public Document(string name)
            : this()
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                throw new ArgumentNullException("name");
            }

            Name = name;
        }

        /// <summary>
        /// Документ в себя ничего не добавляет
        /// </summary>
        /// <param name="obj"></param>
        public override void Add(IComponent obj)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Проверка может ли компонент включать в себя другие элементы
        /// </summary>
        /// <returns>true - композитный false - не композитный </returns>
        public override bool IsComposite()
        {
            return false;
        }

        /// <summary>
        /// Документ из себя ничего не удаляет
        /// </summary>
        /// <param name="component"></param>
        /// <returns></returns>
        public override bool Remove(IComponent component)
        {
            return false;
        }

        /// <summary>
        /// Переименование документа
        /// </summary>
        /// <param name="name">Имя</param>
        /// <returns>true - переименование прошло успешно, иначе false</returns>
        public override bool Rename(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                throw new ArgumentNullException("name");
            }

            if (Parent.IsDuplicateName(name))
            {
                return false;
            }

            this.Name = name;
            return true;
        }
    }
}
