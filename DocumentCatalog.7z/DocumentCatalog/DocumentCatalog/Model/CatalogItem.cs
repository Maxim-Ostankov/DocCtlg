﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DocumentCatalog.Model
{
    /// <summary>
    /// Элемент каталога
    /// </summary>
    public abstract class CatalogItem : IComponent
    {
        /// <summary>
        /// Идентификатор
        /// </summary>
        public int Id { get; internal set; }

        /// <summary>
        /// Наименование 
        /// </summary>       
        public string Name { get; set; }

        /// <summary>
        /// Ссылка на родителя
        /// </summary>
        public Folder Parent { get; set; }

        /// <summary>
        /// Добавление компонента в папку
        /// </summary>
        /// <param name="component">Добавляемый компонент</param>
        abstract public void Add(IComponent component);

        /// <summary>
        /// Удаление компонента из папки
        /// </summary>
        /// <param name="component">Удаляемый элемент</param>
        /// <returns>true - удаление прошло успешно false - удаление произвести не удалось</returns>
        abstract public bool Remove(IComponent component);

        /// <summary>
        /// Проверка может ли компонент включать в себя другие элементы
        /// </summary>
        /// <returns>true - композитный false - не композитный </returns>
        abstract public bool IsComposite();

        /// <summary>
        /// Переименование компонента
        /// </summary>
        abstract public bool Rename(string name);

    }
}
