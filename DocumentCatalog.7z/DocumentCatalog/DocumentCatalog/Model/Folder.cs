﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DocumentCatalog.Model
{
    /// <summary>
    /// Папка каталога
    /// </summary>
    public class Folder : CatalogItem
    {
        /// <summary>
        /// Последний добавленный id
        /// </summary>
        private static int nextNewId { get; set; }

        /// <summary>
        /// Коллекция подэлементов
        /// </summary>
        internal List<CatalogItem> Items { get; set; }


        private Folder()
        {
            Id = --nextNewId;
            Name = string.Empty;
            Items = new List<CatalogItem>();
        }

        public Folder(string name)
            : this()
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                throw new ArgumentNullException("name");
            }

            Name = name;            
        }


        /// <summary>
        /// Добавление компонента в папку
        /// </summary>
        /// <param name="component">Добавляемый компонент</param>
        public override void Add(IComponent component)
        {
            if (component == null)
            {
                throw new ArgumentNullException("component");
            }

            var catalogItem = (CatalogItem)component;

            if (catalogItem == this)
            {
                return;
            }

            if (IsDuplicateName(catalogItem.Name))
            {
                return;
            }

            catalogItem.Parent = this;

            Items.Add(catalogItem);
        }

        /// <summary>
        /// Проверка может ли компонент включать в себя другие элементы
        /// </summary>
        /// <returns>true - композитный false - не композитный </returns>
        public override bool IsComposite()
        {
            return true;
        }

        /// <summary>
        /// Удаление компонента из папки
        /// </summary>
        /// <param name="component">Удаляемый элемент</param>
        /// <returns>true - удаление прошло успешно false - удаление произвести не удалось</returns>
        public override bool Remove(IComponent component)
        {
            return Items.Remove((CatalogItem)component);
        }

        /// <summary>
        /// Количество дочерних элементов
        /// </summary>
        public int ItemsCount
        {
            get { return Items.Count; }
        }

        /// <summary>
        /// Проверка на дубликат с таким же именем в пределах одной папки
        /// </summary>
        /// <param name="itemName"></param>
        /// <returns>true - дубликат false - дубликата нет</returns>
        internal bool IsDuplicateName(string itemName)
        {            
            return this.Items.Any(c => c.Name.Equals(itemName));
        }

        /// <summary>
        /// Переименование компонента
        /// </summary>
        /// <param name="name">Имя</param>
        /// <returns></returns>
        public override bool Rename(string name)
        {
            if (Parent == null)
            {
                return false;
            }

            if (string.IsNullOrWhiteSpace(name))
            {
                throw new ArgumentNullException("name");
            }

            if (Parent.IsDuplicateName(name))
            {
                return false;
            }

            this.Name = name;
            return true;
         }


    }
}
