﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DocumentCatalog.Model
{
    public class DocumentCatalog
    {
        private static DocumentCatalog instance = null;

        private DocumentCatalog() 
        {
            Items = new List<CatalogItem>() { new Folder("Документы") };
            rootItem = Items.Single();
        }

        public List<CatalogItem> Items;
        
        private static object obj = new object();

        public CatalogItem rootItem { get; private set; }  

        public static DocumentCatalog Instance
        {
            get
            {
                lock (obj)
                {
                    if (instance == null)
                        instance = new DocumentCatalog();
                    return instance;
                }
            }
        }
        
        /// <summary>
        /// Поиск элемнта по id
        /// </summary>
        /// <param name="id">искомый id</param>
        /// <returns>Искомый элемент</returns>
        public CatalogItem GetById(int id)
        {
            CatalogItem findItem = null;
            foreach (var item in SearchAlgotithm.BreadthSearch(rootItem))
            {
                if (item.Id == id)
                {
                    findItem = item;
                }
            }
            return findItem;
        }
    }    
}
