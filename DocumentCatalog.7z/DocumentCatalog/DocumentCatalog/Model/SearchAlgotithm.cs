﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DocumentCatalog.Model
{
    public static class SearchAlgotithm
    {
        /// <summary>
        /// Поиск в ширину
        /// </summary>
        /// <param name="startFolder">Папка с которой начинается поиск</param>
        /// <returns></returns>
        public static IEnumerable<CatalogItem> BreadthSearch(CatalogItem startFolder)
        {
            var visited = new HashSet<CatalogItem>();
            var queue = new Queue<CatalogItem>();
            queue.Enqueue(startFolder);
            while (queue.Count != 0)
            {
                var catalogItem = queue.Dequeue();

                if (visited.Contains(catalogItem))
                {
                    continue;
                }

                visited.Add(catalogItem);
                yield return catalogItem;

                if (catalogItem.IsComposite())
                {
                    var folder = (Folder)catalogItem;
                    foreach (var incidentFolder in folder.Items)
                    {
                        queue.Enqueue(incidentFolder);
                    }
                }                
            }
        }

        /// <summary>
        /// Поиск в глубину
        /// </summary>
        /// <param name="startFolder">Папка с которой начинается поиск</param>
        /// <returns></returns>
        public static IEnumerable<CatalogItem> DepthSearch(CatalogItem startFolder)
        {
            var visited = new HashSet<CatalogItem>();
            var stack = new Stack<CatalogItem>();
            stack.Push(startFolder);

            while (stack.Count != 0)
            {
                var catalogItem = stack.Pop();

                if (visited.Contains(catalogItem)) 
                {
                    continue; 
                }
                
                visited.Add(catalogItem);
                yield return catalogItem;

                if (catalogItem.IsComposite())
                {
                    var folder = (Folder)catalogItem;
                    foreach (var incidentFolder in folder.Items)
                    {
                        stack.Push(incidentFolder);
                    }    
                }
                
            }
        }
    }
}
