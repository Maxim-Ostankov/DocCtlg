﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DocumentCatalog.Model
{
    /// <summary>
    /// Представляет общий интерфейс для простых и составных компонентов дерева
    /// </summary>
    public interface IComponent
    {
        void Add(IComponent component);
        bool Remove(IComponent component);        
        bool IsComposite();
    }
}
