﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DocumentCatalogTest
{
    /// <summary>
    /// Тестирование класса документ
    /// </summary>
    [TestClass]
    public class DocTest
    {
        DocumentCatalog.Model.Folder rootFolder = null;

        /// <summary>
        /// Начальные условия для тестирования
        /// </summary>
        [TestInitialize]
        public void CreateRootFolder()
        {
            rootFolder = new DocumentCatalog.Model.Folder("Документы");
        }

        /// <summary>
        /// Создание документа
        /// </summary>
        [TestMethod]
        public void CreateDocumentTest()
        {
            var document = new DocumentCatalog.Model.Document("Doc 1");

            rootFolder.Add(document);

            Assert.AreEqual(1, rootFolder.ItemsCount);

        }
        
        /// <summary>
        /// Удачное удаление документа
        /// </summary>
        [TestMethod]
        public void CorrectRemoveDocTest()
        {
            var doc1 = new DocumentCatalog.Model.Document("Doc 1");
            rootFolder.Add(doc1);

            var d1parent = doc1.Parent;
            var result = d1parent.Remove(doc1);

            Assert.AreEqual(true, result);
        }

        /// <summary>
        /// Неудачное удаление документа
        /// </summary>
        [TestMethod]
        public void IncorrectRemoveDocTest()
        {
            var folder1 = new DocumentCatalog.Model.Folder("Folder 1");
            var document1 = new DocumentCatalog.Model.Document("Doc 1");
            var document2 = new DocumentCatalog.Model.Document("Doc 2");

            rootFolder.Add(folder1);
            rootFolder.Add(document1);
            folder1.Add(document2);

            var d2parent = document2.Parent;
            var result = d2parent.Remove(document1);

            Assert.AreEqual(false, result);
        }
    }
}
