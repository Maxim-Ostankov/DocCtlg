﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DocumentCatalogTest
{
    /// <summary>
    /// Тестирование класса папка
    /// </summary>
    [TestClass]
    public class FolderTest
    {
        DocumentCatalog.Model.Folder rootFolder = null;

        /// <summary>
        /// Начальные условия для тестирования
        /// </summary>
        [TestInitialize]
        public void CreateRootFolder()
        {
            rootFolder = new DocumentCatalog.Model.Folder("Документы");
        }

        /// <summary>
        /// Тест создания каталога
        /// </summary>
        [TestMethod]
        public void CreateCatalog()
        {
            Assert.AreNotEqual(null, rootFolder);
        }

        /*
        /// <summary>
        /// Тест инициализации компонента каталога 
        /// </summary>
        [TestMethod]
        public void InitializeDocCtlgMembersTest()
        {
            //Assert.AreNotEqual(null, rootFolder);
        }
        */
        /// <summary>
        /// Тест создания папки в каталоге документов
        /// </summary>
        [TestMethod]
        public void CreateComponentTest()
        {
            var folder = new DocumentCatalog.Model.Folder("Folder1");
            rootFolder.Add(folder);

            Assert.AreEqual(1, rootFolder.ItemsCount);
        }

        /// <summary>
        /// Удачное удаление папки
        /// </summary>
        [TestMethod]
        public void CorrectRemoveTest()
        {
            var folder1 = new DocumentCatalog.Model.Folder("Folder 1");
            folder1.Add(folder1);

            var folder2 = new DocumentCatalog.Model.Folder("Folder 2");
            folder1.Add(folder2);

            rootFolder.Add(folder1);

            var f2parent = folder2.Parent;
            var result = f2parent.Remove(folder2);

            Assert.AreEqual(true, result);
        } 

        /// <summary>
        /// Неудачное удаление папки
        /// </summary>
        [TestMethod]
        public void IncorrectRemoveTest()
        {
            var folder1 = new DocumentCatalog.Model.Folder("Folder 1");
            var folder2 = new DocumentCatalog.Model.Folder("Folder 2");
            
            folder1.Add(folder2);
            rootFolder.Add(folder1);

            var f2parent = folder2.Parent;
            var result = f2parent.Remove(folder1);

            Assert.AreEqual(false, result);
        }

        [TestMethod]
        public void SingletonTest()
        {
            Assert.AreSame(DocumentCatalog.Model.DocumentCatalog.Instance, DocumentCatalog.Model.DocumentCatalog.Instance);
        }

        /*
        // Корректное переименование компонента
        [TestMethod]
        public void CorrectRenameTest()
        {

        } 

        // Некоректное переименование компонента
        [TestMethod]
        public void IncorrectRenameTest()
        {
            
        }

        // Корректное получение компонента
        [TestMethod]
        public void CorrectGetTest()
        {

        } 

        // Некорректное получение компонента
        [TestMethod]
        public void IncorrectGetTest()
        {
            
        }

        // Проверка на существование компонента
        [TestMethod]
        public void ExistTest()
        {

        }
 
        // Проверка на отсутствие компонента
        [TestMethod]
        public void NotExistTest()
        {
            
        }

        // Корректное перемещение компонента
        [TestMethod]
        public void CorrectMoveTest()
        {

        } 

        // Некорректное перемещение компонента
        [TestMethod]
        public void IncorrectMoveTest()
        {
            
        }

        // Корректное получение Родителя
        [TestMethod]
        public void CorrectParentTest()
        {

        } 

        // Некорректное получение Родителя
        [TestMethod]
        public void IncorrectParentTest()
        {
            
        }

        // Корректное получение Ребенка
        [TestMethod]
        public void CorrectChildTest()
        {

        } 

        // Некорректное получчение Ребенка
        [TestMethod]
        public void IncorrectChildTest()
        {

        }
         */
    }
}
